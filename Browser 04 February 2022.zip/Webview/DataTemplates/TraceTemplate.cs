﻿class TraceTemplate : Grid
{
    Path icon;
    TextBlock hop, msg, ip, hopTime, totalTime;
    public TraceTemplate() {
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition());

        icon = new Path() { 
            Width = 12,
            Height = 12,
            Stretch = Stretch.Uniform,
            HorizontalAlignment = HorizontalAlignment.Center
        };

        hop = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Center };
        msg = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Center };
        ip = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Center };
        hopTime = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right};
        totalTime = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };

        Grid.SetColumn(hop, 1);
        Grid.SetColumn(msg, 2);
        Grid.SetColumn(ip, 3);
        Grid.SetColumn(hopTime, 4);
        Grid.SetColumn(totalTime, 5);
        Children.Add(icon);
        Children.Add(hop);
        Children.Add(msg);
        Children.Add(ip);
        Children.Add(hopTime);
        Children.Add(totalTime);
    }

    public override void EndInit() {
        base.EndInit();
        var trace = (Trace)DataContext;
        if (trace.Icon.Equals(Icons.DownArrow)) {
            icon.Fill = Brushes.CornflowerBlue;
            msg.Text = "Ok";
        }
        else if (trace.Icon.Equals(Icons.Exclamation)) {
            icon.Fill = Brushes.Coral;
            msg.Text = "Timeout";
        }
        else if (trace.Icon.Equals(Icons.Close)) {
            icon.Fill = Brushes.Red;
            msg.Text = "Fail";
        }
        else {
            icon.Fill = Brushes.Green;
            msg.Text = "Success";
        }
        icon.Data = Geometry.Parse(trace.Icon);
        hop.Text = trace.HopNo.ToString(Constants.NumericFormat);
        ip.Text = trace.IP;
        hopTime.Text = trace.DiscoveryTime.ToString("N0") + " ms";
        totalTime.Text = trace.TotalTime.ToString("N0") + " ms";
    }
}

