﻿class RequestTemplate : Grid
{
    ColorAnimation anim;
    SolidColorBrush brush;
    TextBlock time, length, uri;

    public RequestTemplate() {
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(60) });
        ColumnDefinitions.Add(new ColumnDefinition());
        time = new TextBlock();
        length = new TextBlock() { 
            HorizontalAlignment = HorizontalAlignment.Right,
            Margin = new Thickness(0, 0, 10, 0)
        };
        uri = new TextBlock() { TextWrapping = TextWrapping.Wrap };
        Grid.SetColumn(length, 1);
        Grid.SetColumn(uri, 2);
        Children.Add(time);
        Children.Add(length);
        Children.Add(uri);
        
        anim = new ColorAnimation() {
            Duration = TimeSpan.FromMilliseconds(750),
            From = Colors.CornflowerBlue,
            To = Colors.Transparent
        };
        brush = new SolidColorBrush(Colors.Transparent);
        Background = brush;
        Loaded += animate;
        Unloaded += onUnloaded;
    }
    public override void EndInit() {
        base.EndInit();
        var request = (Request)DataContext;
        uri.Text = request.Uri;
        time.Text = request.Time;
        length.Text = request.Length.ToString(Constants.NumericFormat);
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= animate;
        Unloaded -= onUnloaded;
    }

    void animate(object sender, RoutedEventArgs e) => brush.BeginAnimation(SolidColorBrush.ColorProperty, anim);
}
