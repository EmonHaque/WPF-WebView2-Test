﻿class HeaderBlock : TextBlock
{
    ColorAnimation anim;
    SolidColorBrush brush;
    Run name, count;
    public HeaderBlock() {    
        brush = new SolidColorBrush(Colors.Transparent);
        Background = brush;
        name = new Run();
        count = new Run();
        name.SetBinding(Run.TextProperty, new Binding("DataContext." + nameof(GroupItem.Name)) {
            Mode = BindingMode.OneWay,
            RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(Expander), 1)
        });
        count.SetBinding(Run.TextProperty, new Binding("DataContext.ItemCount") {
            Mode = BindingMode.OneWay,
            RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(Expander), 1)
        });
        Inlines.Add(name);
        Inlines.Add(" : ");
        Inlines.Add(count);

        anim = new ColorAnimation() {
            Duration = TimeSpan.FromMilliseconds(750),
            From = Colors.CornflowerBlue,
            To = Colors.Transparent
        };
        var dp = DependencyPropertyDescriptor.FromProperty(Run.TextProperty, typeof(TextBlock));
        dp.AddValueChanged(count, (s, a) => brush.BeginAnimation(SolidColorBrush.ColorProperty, anim));
    }
}
class ExpTemplate : Grid
{
    BiState state;
    ContentPresenter header;
    ItemsPresenter content;
    public ExpTemplate() {
        state = new BiState();
        header = new ContentPresenter() { ContentSource = "Header"};
        content = new ItemsPresenter();
        Grid.SetColumn(header, 1);
        Grid.SetRow(content, 1);
        Grid.SetColumn(content, 1);
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
        ColumnDefinitions.Add(new ColumnDefinition());
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition());
       
        state.SetValue(BiState.MarginProperty, new Thickness(0, 0, 5, 0));
        state.SetBinding(BiState.IsTrueProperty, new Binding(nameof(Expander.IsExpanded)) {
            Mode = BindingMode.TwoWay,
            RelativeSource = new RelativeSource(RelativeSourceMode.TemplatedParent)
        });
        var dp = DependencyPropertyDescriptor.FromProperty(BiState.IsTrueProperty, typeof(BiState));
        dp.AddValueChanged(state, (s, a) => {
            if (!state.IsTrue) content.Height = 0;
        });
        Children.Add(state);
        Children.Add(header);
        Children.Add(content);
    }
}
class RequestGroupTemplate : ControlTemplate
{
    public RequestGroupTemplate() {
        TargetType = typeof(GroupItem);
        var expander = new FrameworkElementFactory(typeof(Expander));
        var items = new FrameworkElementFactory(typeof(ItemsPresenter));
        expander.SetValue(Expander.TemplateProperty, new ExpanderTemplate());
        //expander.SetValue(Expander.TemplateProperty, Helper.GetControlTemplate(typeof(Expander), typeof(ExpTemplate)));
        expander.SetValue(Expander.HeaderTemplateProperty, Helper.GetDataTemplate(typeof(HeaderBlock)));
        expander.AppendChild(items);

        VisualTree = expander;
    }
}
