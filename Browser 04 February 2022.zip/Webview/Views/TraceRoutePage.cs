﻿
class TraceRoutePage : Page
{
    public override PageType Type => PageType.TraceRoute;
    public override UIElement Content => container;
    Grid container;
    TextBlock addressBlock, statusBlock;
    TextBox box;
    InfiniteCircle circle;
    ListBox routes;
    ObservableCollection<Trace> list;
     
    string host;
    const int timeOut = 2000;
    int maxTry = 30;
    byte[] buffer = new byte[32];
    bool isPinging, isCancelled;
    Ping ping;
    PingReply reply;

    public TraceRoutePage() {
        HeaderText = "Trace Route";
        addressBlock = new TextBlock() { Text = "address: ", Margin = new Thickness(3, 0, 5, 0) };
        box = new TextBox();
        
        circle = new InfiniteCircle();
        Grid.SetColumn(box, 1);
        Grid.SetColumn(circle, 2);
        var addressPanel = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(){Width = GridLength.Auto},
                new ColumnDefinition(),
                new ColumnDefinition(){Width = GridLength.Auto}
            },
            Children = { addressBlock, box, circle }
        };
        routes = new ListBox() {
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            BorderThickness = new Thickness(0),
            Background = null,
            ItemTemplate = Helper.GetDataTemplate(typeof(TraceTemplate))
        };
        list = new ObservableCollection<Trace>();
        routes.ItemsSource = list;

        statusBlock = new TextBlock() { 
            HorizontalAlignment = HorizontalAlignment.Right,
            Margin = new Thickness(0,0,3,3)
        };
        Grid.SetRow(statusBlock, 1);
        Grid.SetRow(routes, 2);
        container = new Grid() {
            Margin = new Thickness(3),
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            Children = { addressPanel, statusBlock, routes }
        };
        ping = new Ping();
        box.KeyUp += onKeyUp;
        App.Current.Dispatcher.InvokeAsync(box.Focus, DispatcherPriority.Background);
    }
    protected override void unload() {
        base.unload();
        box.KeyUp -= onKeyUp;
        ping.Dispose();
    }
    protected override void handleSelectionChange() {
        base.handleSelectionChange();
        App.Current.Dispatcher.InvokeAsync(box.Focus, DispatcherPriority.Background);
        box.SelectAll();
    }
    async void onKeyUp(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;      
        host = box.Text;
        if (isPinging) {
            isCancelled = true;
            while (isPinging) await Task.Delay(100);
        }
        statusBlock.Text = "Route to: " + host; 
        if (circle.Visibility != Visibility.Visible) 
            circle.Visibility = Visibility.Visible;
        isCancelled = false;
        list.Clear();
        await Task.Run(startPing);
        circle.Visibility = Visibility.Collapsed;
    }

    void startPing() {
        isPinging = true;
        double end = 0;
        double totalTime = 0;
        int currentHOP = 0;
        bool isValidHost = false;
       
        var start = DateTime.UtcNow;
        try {
            reply = ping.Send(host, timeOut, buffer, new PingOptions(1, true));
            end = Math.Round((DateTime.UtcNow - start).TotalMilliseconds, 0);
            totalTime += end;
            currentHOP++;
            isValidHost = true;
        }
        catch {
            isValidHost = false;
            App.Current.Dispatcher.Invoke(() => InfoDialog.Activate(App.Current.MainWindow, "Error", "Provide a valid address"));
        }
        if (!isValidHost) {
            isPinging = false;
            return;
        }
        App.Current.Dispatcher.Invoke(() => list.Add(new Trace() {
            Icon = Icons.DownArrow,
            HopNo = currentHOP,
            IP = reply.Address.ToString(),
            DiscoveryTime = end,
            TotalTime = totalTime
        }));

        bool isSuccess = false;
        for (int hop = 2; hop < maxTry; hop++) {
            var trace = new Trace();
            start = DateTime.UtcNow;
            reply = ping.Send(host, timeOut, buffer, new PingOptions(hop, true));
            switch (reply.Status) {
                case IPStatus.Success:
                    end = Math.Round((DateTime.UtcNow - start).TotalMilliseconds, 0);
                    totalTime += end;
                    currentHOP++;
                    trace.Icon = Icons.Tick;
                    trace.HopNo = currentHOP;
                    isSuccess = true;
                    break;
                case IPStatus.TimedOut:
                    end = Math.Round((DateTime.UtcNow - start).TotalMilliseconds, 0);
                    totalTime += end;
                    trace.Icon = Icons.Exclamation;
                    trace.HopNo = 0;
                    break;
                case IPStatus.TtlExpired:
                    end = Math.Round((DateTime.UtcNow - start).TotalMilliseconds, 0);
                    totalTime += end;
                    currentHOP++;
                    trace.Icon = Icons.DownArrow;
                    trace.HopNo = currentHOP;
                    break;
            }
            if (isCancelled) break;
            trace.IP = reply.Address.ToString();
            trace.DiscoveryTime = end;
            trace.TotalTime = totalTime;
            App.Current.Dispatcher.Invoke(() => list.Add(trace));
            if (isSuccess) break;
        }
        if (!isSuccess) {
            App.Current.Dispatcher.Invoke(() => list.Add(new Trace() {
                IP = reply.Address.ToString(),
                Icon = Icons.Close,
                HopNo = 0,
                DiscoveryTime = end,
                TotalTime = totalTime,
            }));
        }
        isPinging = false;
    }
}

