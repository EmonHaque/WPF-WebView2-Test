﻿abstract class Page
{
    MenuItem closeMenu;
    string headerText;
    protected string HeaderText {
        get { return headerText; }
        set { headerText = value; Tab.Text = value; }
    }
    protected ContextMenu HeaderMenu { get; set; }
    public abstract PageType Type { get; }
    public abstract UIElement Content { get; }
    public Header Tab { get; set; }
    public event Action<Page> SelectionChanged, CloseRequested;

    public Page() {
        Tab = new Header();
        closeMenu = new MenuItem() { Icon = Helper.getIcon(Icons.Close), Header = "Close Tab" };
        HeaderMenu = new ContextMenu() { Items = {closeMenu} };
        Tab.ContextMenu = HeaderMenu;
        closeMenu.Click += onContextCloseClicked;
        Tab.SelectionChanged += onSelectionChanged;
        Tab.CloseRequested += onCloseRequested;
    }

    void onCloseRequested(Header h) {
        CloseRequested?.Invoke(this);
        if (this is not RequestPage) unload();
    }
    void onSelectionChanged(Header h) {
        h.IsSelected = true;
        SelectionChanged?.Invoke(this);
        handleSelectionChange();
    }
    void onContextCloseClicked(object sender, RoutedEventArgs e) => Tab.RaiseCloseRequested();
    protected virtual void unload() {
        closeMenu.Click -= onContextCloseClicked;
        Tab.SelectionChanged -= onSelectionChanged;
        Tab.CloseRequested -= onCloseRequested;
    }
    protected virtual void handleSelectionChange() { }
}

