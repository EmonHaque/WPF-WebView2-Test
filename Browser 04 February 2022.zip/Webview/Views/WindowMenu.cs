﻿using System.IO;

class WindowMenu : ContextMenu
{
    MenuItem requestLog, netstats, sniff, traceRoute;
    Action webRequestLogAction;
    ObservableCollection<Page> pages;
    public WindowMenu(Action webRequestLogAction, ObservableCollection<Page> pages) {
        this.webRequestLogAction = webRequestLogAction;
        this.pages = pages;
        requestLog = new MenuItem() { Icon = Helper.getIcon(Icons.Log), Header = "Request Log" };
        netstats = new MenuItem() { Icon = Helper.getIcon(Icons.Network), Header = "Netstat" };
        sniff = new MenuItem() { Icon = Helper.getIcon(Icons.Packet), Header = "Sniffer" };
        traceRoute = new MenuItem() { Icon = Helper.getIcon(Icons.Route), Header = "Trace Route" };
        Items.Add(requestLog);
        Items.Add(netstats);
        Items.Add(sniff);
        Items.Add(traceRoute);
    }
    protected override void OnOpened(RoutedEventArgs e) {
        base.OnOpened(e);
        requestLog.Click += onRequestLog;
        netstats.Click += onNetStat;
        sniff.Click += onSniff;
        traceRoute.Click += onTraceRoute;
    }

    void onTraceRoute(object sender, RoutedEventArgs e) {
        var page = new TraceRoutePage();
        pages.Add(page);
    }

    void onSniff(object sender, RoutedEventArgs e) {
        var exe = "Packetview.exe";
        bool exists = File.Exists(exe);
        if (!exists) throw new FileNotFoundException("Process: " + exe + " doesn't exsits");
        var path = AppDomain.CurrentDomain.BaseDirectory;
        var process = new ProcessStartInfo(path + exe, "nothing");
        process.UseShellExecute = true;
        process.Verb = "runas";
        Process.Start(process);
    }

    void onNetStat(object sender, RoutedEventArgs e) {
        var exe = "Netstat.exe";
        bool exists = File.Exists(exe);
        if (!exists) throw new FileNotFoundException("Process: " + exe + " doesn't exsits");
        var path = AppDomain.CurrentDomain.BaseDirectory;
        var process = new ProcessStartInfo(path + exe);
        Process.Start(process);
    }

    protected override void OnClosed(RoutedEventArgs e) {
        base.OnClosed(e);
        requestLog.Click -= onRequestLog;
        netstats.Click -= onNetStat;
        sniff.Click -= onSniff;
        traceRoute.Click -= onTraceRoute;
    }

    void onRequestLog(object sender, RoutedEventArgs e) => webRequestLogAction();
}

