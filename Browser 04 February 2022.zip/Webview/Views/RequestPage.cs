﻿using System.IO;

class RequestPage : Page
{
    public override PageType Type => PageType.RequestLog;
    public override UIElement Content => content;

    ContextMenu pageMenu;
    public static ObservableCollection<Request> requestCollection;
    CollectionViewSource requestSource;
    TextBlock logCount;
    ListBox logBox;
    ActionButton clearLog, exportCSV;
    MenuItem blockMenu, copyMenu;
    Grid content;

    public RequestPage() : base() {  
        blockMenu = new MenuItem() { Icon = Helper.getIcon(Icons.Block), Header = "Blacklist" };
        copyMenu = new MenuItem() { Icon = Helper.getIcon(Icons.Copy), Header = "Copy link" };
        pageMenu = new ContextMenu() { Items = { blockMenu, copyMenu } };
        HeaderText = "Request Log";

        logCount = new TextBlock() { Text = "0" };
        clearLog = new ActionButton() {
            Icon = Icons.Broom,
            Margin = new Thickness(5, 0, 5, 0),
            Command = clearLogBox
        };
        exportCSV = new ActionButton() {
            Icon = Icons.CSV,
            Command = exportLogs
        };

        var buttonsPanel = new StackPanel() {
            HorizontalAlignment = HorizontalAlignment.Right,
            Orientation = Orientation.Horizontal,
            Margin = new Thickness(0, 5, 5, 5),
            Children = { logCount, clearLog, exportCSV }
        };

        requestCollection = new ObservableCollection<Request>();
        requestSource = new CollectionViewSource() {
            Source = requestCollection,
            IsLiveGroupingRequested = true,
            LiveGroupingProperties = { nameof(Request.Title), nameof(Request.Type) }
        };
        requestSource.View.GroupDescriptions.Add(new PropertyGroupDescription(nameof(Request.Title)));
        requestSource.View.GroupDescriptions.Add(new PropertyGroupDescription(nameof(Request.Type)));

        logBox = new ListBox() {
            Margin = new Thickness(5),
            Background = Brushes.LightGray,
            BorderThickness = new Thickness(0),
            ItemsSource = requestSource.View,
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            ItemTemplate = Helper.GetDataTemplate(typeof(RequestTemplate)) ,
            GroupStyle = {
                new GroupStyle() {
                    ContainerStyle = new Style(typeof(GroupItem)) {
                        Setters = { new Setter(GroupItem.TemplateProperty, new RequestGroupTemplate())}
                    }
                }
            },
            Resources = {
                {
                    typeof(ListBoxItem),
                    new Style(typeof(ListBoxItem)) {
                        Setters = { new Setter() { Property = ListBoxItem.ContextMenuProperty, Value = pageMenu } }
                    }
                }
            }
        };
        logBox.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        Grid.SetRow(logBox, 1);

        content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { buttonsPanel, logBox }
        };

        logCount.SetBinding(TextBlock.TextProperty, new Binding("Items.Count") {
            Source = logBox, StringFormat = "N0"
        });

        subscribe();
    }

    protected override void unload() {
        base.unload();
        blockMenu.Click -= addToBlackList;
        copyMenu.Click -= copyLinkToClipBoard;
    }

    void subscribe() {
        blockMenu.Click += addToBlackList;
        copyMenu.Click += copyLinkToClipBoard;
    }

    void clearLogBox() {
        if (!logBox.HasItems) return;
        Monitor.Enter(App.logLock);
        requestCollection.Clear();
        Monitor.Exit(App.logLock);
    }
    void exportLogs() { }

    void copyLinkToClipBoard(object sender, RoutedEventArgs e) {
        string uri = ((Request)logBox.SelectedItem).Uri;
        Clipboard.SetText(uri);
    }

    void addToBlackList(object sender, RoutedEventArgs e) {
        string uri = ((Request)logBox.SelectedItem).Uri;
        BlacklistDialog.Activate("Confirm link", uri);
        if (!BlacklistDialog.IsOk) return;
        
        Monitor.Enter(App.blackListLock);
        App.blackList.Add(BlacklistDialog.URL);
        File.AppendAllLines(App.blackListFilePath, new string[] { BlacklistDialog.URL });
        Monitor.Exit(App.blackListLock);
    }
}

