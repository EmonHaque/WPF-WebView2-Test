﻿
class WebPage : Page
{
    public override PageType Type => PageType.WebPage;
    public override UIElement Content => content;

    WebView2 web;
    CoreWebView2 view;
    CoreWebView2WebResourceResponse blockResponse;
    TextBox box;
    TextBlock blockCount;
    ActionButton back, forward, reload, favorite, print, log;
    InfiniteCircle circle;
    MenuItem loggingMenu;
    string requestedUrl;
    int blockCounter;
    bool isLogging;
    string userDataPath = "UserData";
    Grid content, addressBar;
    public event Action LogRequested;
    public event Action<bool> FullScreenRequested;
    public event Action<string> NewTabRequested;

    public WebPage() : base() {
        web = new WebView2() {
            Margin = new Thickness(3),
            DefaultBackgroundColor = System.Drawing.Color.LightGray
        };
        createAddressBar();
        loggingMenu = new MenuItem() { Icon = Helper.getIcon(Icons.Log), Header = "Start Logging" };
        HeaderMenu.Items.Insert(0, loggingMenu);
        HeaderText = "New Tab";

        Grid.SetRow(web, 1);
        content = new Grid() {
            RowDefinitions = {
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { addressBar, web }
        };
        loadAndSubscribe();
    }
    public WebPage(string requestedUrl) : this() {
        this.requestedUrl = requestedUrl;
    }

    async void onKeyUp(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        
        string url = box.Text;
        if (Keyboard.Modifiers == ModifierKeys.Control) url = "http://" + url + ".com";
        else if (!(url.StartsWith("https://") || url.StartsWith("http://")))
            url = "http://" + url;
        view.Navigate(url);
    }
    async void loadAndSubscribe() {
        var userData = await CoreWebView2Environment.CreateAsync(null, userDataPath);
        await web.EnsureCoreWebView2Async(userData);
        view = web.CoreWebView2;
        //view.Settings.IsGeneralAutofillEnabled = true;
        //view.Settings.IsPasswordAutosaveEnabled = true;
        view.AddWebResourceRequestedFilter("*", CoreWebView2WebResourceContext.All);
        blockResponse ??= view.Environment.CreateWebResourceResponse(null, 404, "blocked", "blocked");
        view.WebResourceRequested += onWebResourceRequested;
        view.DocumentTitleChanged += onTitleChanged;
        view.NewWindowRequested += onNewWindowRequest;
        view.ContainsFullScreenElementChanged += onFullScreenRequested;
        view.NavigationStarting += onNavigationStarted;
        view.DOMContentLoaded += onDOMLoaded;
        box.KeyUp += onKeyUp;

        loggingMenu.Click += toggleLog;
        if (requestedUrl != null) {
            view.Navigate(requestedUrl);
            box.Text = requestedUrl;
        }
        box.Focus();
    }
    void onDOMLoaded(object? sender, CoreWebView2DOMContentLoadedEventArgs e) {
        circle.Visibility = Visibility.Collapsed;
    }
    void onNavigationStarted(object? sender, CoreWebView2NavigationStartingEventArgs e) {
        if (circle.Visibility != Visibility.Visible) 
            circle.Visibility = Visibility.Visible;
    }
    void onFullScreenRequested(object? sender, object e) {
        bool isFullScreen = view.ContainsFullScreenElement;
        if (isFullScreen) {
            addressBar.Visibility = Visibility.Collapsed;
            web.Margin = new Thickness(0);
        }
        else {
            addressBar.Visibility = Visibility.Visible;
            web.Margin = new Thickness(3);
        }
        FullScreenRequested?.Invoke(isFullScreen);
    }
    protected override void unload() {
        base.unload();
        box.KeyUp -= onKeyUp;
        loggingMenu.Click -= toggleLog;
        if (view != null) {
            view.DocumentTitleChanged -= onTitleChanged;
            view.NewWindowRequested -= onNewWindowRequest;
            view.WebResourceRequested -= onWebResourceRequested;
            view.ContainsFullScreenElementChanged -= onFullScreenRequested;
            view.NavigationStarting -= onNavigationStarted;
            view.DOMContentLoaded -= onDOMLoaded;
        }
        web.Dispose();
    }
    protected override void handleSelectionChange() {
        base.handleSelectionChange();
        App.Current.Dispatcher.InvokeAsync(box.Focus, DispatcherPriority.Background);
        box.SelectAll();
    }
    void toggleLog(object sender, RoutedEventArgs e) {
        if (!isLogging) {
            isLogging = true;
            log.Icon = Icons.LogNegative;
            log.ToolTip = "Stop logging";
            loggingMenu.Header = "Stop logging";
            LogRequested?.Invoke();
        }
        else {
            isLogging = false;
            log.Icon = Icons.LogPositive;
            log.ToolTip = "Start logging";
            loggingMenu.Header = "Start logging";
        }
    }
    void onWebResourceRequested(object? sender, CoreWebView2WebResourceRequestedEventArgs e) {
        Monitor.Enter(App.blackListLock);
        bool isBlocked = false;
        foreach (var site in App.blackList) {
            if (e.Request.Uri.Contains(site)) {
                e.Response = blockResponse;
                blockCounter++;
                blockCount.Text = blockCounter.ToString("N0");
                isBlocked = true;
                break;
            }
        }
        Monitor.Exit(App.blackListLock);

        if (isBlocked) return;
        if (!isLogging) return;
        var request = new Request() {
            Title = view.DocumentTitle,
            Uri = e.Request.Uri,
            Type = e.Request.Method,
            Length = e.Request.Method == "POST" ? e.Request.Content == null ? 0 : e.Request.Content.Length : 0,
            Time = DateTime.Now.ToString("HH:mm:ss")
        };
        Monitor.Enter(App.logLock);
        RequestPage.requestCollection.Insert(0, request);
        Monitor.Exit(App.logLock);
    }
    void onNewWindowRequest(object? sender, CoreWebView2NewWindowRequestedEventArgs e) {
        e.Handled = true;
        NewTabRequested?.Invoke(e.Uri);
    }
    void onTitleChanged(object? sender, object e) {
        box.Text = view.Source;
        box.CaretIndex = box.Text.Length;
        blockCounter = 0;
        blockCount.Text = "0";
        HeaderText = view.DocumentTitle;
    }
    void createAddressBar() {
        back = new ActionButton() { Icon = Icons.Back, Space = true, Command = web.GoBack };
        forward = new ActionButton() { Icon = Icons.Forward, Space = true, Command = web.GoForward };
        reload = new ActionButton() { Icon = Icons.Refresh, Space = true, Command = web.Reload };
        favorite = new ActionButton() { Icon = Icons.Favorite, Space = true, Command = onFavorite };
        print = new ActionButton() { Icon = Icons.Print, Space = true, Command = onPrint };
        log = new ActionButton() { Icon = Icons.LogPositive, Space = true, Command = () => toggleLog(null, null), ToolTip = "Start logging" };
        blockCount = new TextBlock() { Text = "0", VerticalAlignment = VerticalAlignment.Center };
        box = new TextBox() {
            FontSize = 14,
            Margin = new Thickness(5, 0, 5, 0),
            BorderThickness = new Thickness(0, 0, 0, 1)
        };
        circle = new InfiniteCircle();
        Grid.SetColumn(forward, 1);
        Grid.SetColumn(reload, 2);
        Grid.SetColumn(box, 3);
        Grid.SetColumn(blockCount, 4);
        Grid.SetColumn(favorite, 5);
        Grid.SetColumn(print, 6);
        Grid.SetColumn(log, 7);
        Grid.SetColumn(circle, 8);
        addressBar = new Grid() {
            Margin = new Thickness(0, 0, 3, 0),
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { back, forward, reload, box, blockCount, favorite, print, log, circle },
        };
    }
    void onFavorite() { }
    async void onPrint() => await view.ExecuteScriptAsync("window.print();");
}

