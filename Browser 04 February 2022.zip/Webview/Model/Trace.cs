﻿class Trace
{
    public string Icon { get; set; }
    public int HopNo { get; set; }
    public string IP { get; set; }
    public double DiscoveryTime { get; set; }
    public double TotalTime { get; set; }
}

