﻿class Request
{
    public string Title { get; set; }
    public string Uri { get; set; }
    public string Type { get; set; }
    public string Time { get; set; }
    public long Length { get; set; }
}

