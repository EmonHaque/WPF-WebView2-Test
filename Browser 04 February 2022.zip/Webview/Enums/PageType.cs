﻿enum PageType
{
    WebPage,
    RequestLog,
    TraceRoute
}

