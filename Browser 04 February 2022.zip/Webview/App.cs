﻿using System.IO;

class App : Application
{
    public static object logLock, blackListLock;
    public static List<string> blackList;
    public static string blackListFilePath = "blacklist.txt";
    public App() {
        Current.DispatcherUnhandledException += unhandledHandler;
        logLock = new object();
        blackListLock = new object();
        blackList = new List<string>();

        if (File.Exists(blackListFilePath)) {
            var lines = System.IO.File.ReadAllLines(blackListFilePath);
            foreach (var line in lines) {
                if (string.IsNullOrWhiteSpace(line) || string.IsNullOrEmpty(line) || line.StartsWith("!"))
                    continue;
                blackList.Add(line);
            }
        }
        else File.Create(blackListFilePath);
    }

    [STAThread]
    static void Main(string[] args) => new App().Run();
    protected override void OnStartup(StartupEventArgs e) {
        base.OnStartup(e);
        App.Current.MainWindow = new WebWindow();
        App.Current.MainWindow.Show();
        Current.Resources.Add(SystemParameters.VerticalScrollBarWidthKey, 12d);
        Current.Resources.Add(SystemParameters.HorizontalScrollBarHeightKey, 12d);
        Control.StyleProperty.OverrideMetadata(typeof(ScrollBar), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = { new Setter(ScrollBar.TemplateProperty, new VScrollTemplate()) },
                Triggers = {
                        new Trigger() {
                            Property = ScrollBar.OrientationProperty,
                            Value = Orientation.Horizontal,
                            Setters = { new Setter(ScrollBar.TemplateProperty, new HScrollTemplate()) }
                        }
                    }
            }
        });
    }

    void unhandledHandler(object sender, DispatcherUnhandledExceptionEventArgs e) {
        InfoDialog.Activate(App.Current.MainWindow, "Exception", e.Exception.Message + "\n" + e.Exception.StackTrace);
        e.Handled = true;
    }
}

