﻿class Header : Border
{
    string text = "";
    public string Text {
        get { return text; }
        set {
            if (text.Equals(value)) return;
            text = value; 
            block.Text = value;
            ToolTip = value;
        }
    }
    bool isSelected;
    public bool IsSelected {
        get { return isSelected; }
        set { 
            isSelected = value;
            if (isSelected) {
                Background = selectedBackground;
                BorderThickness = selectedThickness;
                BorderBrush = selectedBorder;
                
            }
            else {
                Background = normalBackground;
                BorderThickness = normalThickness;
                BorderBrush = normalBorder;
            }
        }
    }
    public bool IsBeingDragged { get; set; }
    public event Action<Header> SelectionChanged, CloseRequested;
    TextBlock block;
    ActionButton close;
    StackPanel container;
    SolidColorBrush normalBackground, highlightBackground, selectedBackground, normalBorder, selectedBorder;
    Thickness normalThickness, selectedThickness;

    public Header() {     
        normalBackground = Brushes.LightGray;
        highlightBackground = Brushes.CornflowerBlue;
        selectedBackground = Brushes.LightBlue;
        normalBorder = Brushes.CornflowerBlue;
        selectedBorder = Brushes.Blue;
        normalThickness = new Thickness(1);
        selectedThickness = new Thickness(1, 1, 1, 0);
        block = new TextBlock() { 
            Margin = new Thickness(2,0,5,0),
            IsHitTestVisible = false,
            MaxWidth = 100,
            TextTrimming = TextTrimming.CharacterEllipsis,
            Text = "New Tab"
        };
        close = new ActionButton() { 
            Icon = Icons.CloseCircle,
            Margin = new Thickness(0, 0, 2, 0)
        };
        container = new StackPanel() {
            Orientation = Orientation.Horizontal,
            Children = { block, close }
        };
        CornerRadius = new CornerRadius(10, 10, 0, 0);
        BorderThickness = normalThickness;
        BorderBrush = normalBorder;
        Background = normalBackground;
        Padding = new Thickness(2,2,2,2);
        Margin = new Thickness(1, 1, 0, 5);
        Child = container;
    }
    public void RaiseCloseRequested() => CloseRequested?.Invoke(this);
    protected override void OnDragEnter(DragEventArgs e) {
        if(!IsBeingDragged) Background = Brushes.Coral;
    }
    protected override void OnDragLeave(DragEventArgs e) {
        if (IsSelected) Background = selectedBackground;
        else Background = normalBackground;
    }
    protected override void OnDrop(DragEventArgs e) {
        if (IsSelected) Background = selectedBackground;
        else Background = normalBackground;
    }
    protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) {
        if(e.Source is ActionButton || e.Source is Path) {
            RaiseCloseRequested();
            return;
        }
        if (!IsSelected) {
            SelectionChanged?.Invoke(this);
            IsSelected = true;
        }     
    }
    protected override void OnMouseEnter(MouseEventArgs e) {
        if(!IsSelected) Background = highlightBackground;
    }
    protected override void OnMouseLeave(MouseEventArgs e) {
        if (!IsSelected) Background = normalBackground; 
    }
    protected override void OnGiveFeedback(GiveFeedbackEventArgs e) {
        Mouse.SetCursor(Cursors.Hand);
        e.Handled = true;
    }
}
