﻿
class BiState : Border
{
    Path icon;
    SolidColorBrush brush;
    Color trueColor, falseColor, highlightColor, downColor, disabledColor;
    ColorAnimation anim;
    Geometry trueGeo, falseGeo;

    public string TrueIcon { get; set; }
    public string FalseIcon { get; set; }

    public BiState() {
        trueColor = Colors.Green;
        falseColor = Colors.Black;
        highlightColor = Colors.CornflowerBlue;
        downColor = Colors.Red;
        disabledColor = Colors.LightGray;
        brush = new SolidColorBrush(falseColor);
        icon = new Path() {
            Stretch = Stretch.Uniform,
            Fill = brush,
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(5, 0, 0, 0)
        };
        Child = icon;
        anim = new ColorAnimation() {
            Duration = TimeSpan.FromMilliseconds(250),
            EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
        };
        Background = Brushes.Transparent;
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }

    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
    }
    void onLoaded(object sender, RoutedEventArgs e) {
        if (TrueIcon == null) TrueIcon = Icons.Minus;
        if (FalseIcon == null) FalseIcon = Icons.Plus;
        trueGeo = Geometry.Parse(TrueIcon);
        falseGeo = Geometry.Parse(FalseIcon);
        if (IsTrue) {
            icon.Data = trueGeo;
            animateBrush(trueColor);
        }
        else {
            icon.Data = falseGeo;
            animateBrush(falseColor);
        }
        if (double.IsNaN(Width)) icon.Width = icon.Height = 12; 
    }
    void animateBrush(Color c) {
        anim.To = c;
        brush.BeginAnimation(SolidColorBrush.ColorProperty, anim);
    }
    void onEnabledChanged(object sender, DependencyPropertyChangedEventArgs e) {
        if (IsEnabled) animateBrush(IsTrue ? trueColor : falseColor);
        else animateBrush(disabledColor);
    }
    protected override void OnMouseEnter(MouseEventArgs e) => animateBrush(highlightColor);
    protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) => IsTrue = !IsTrue;
    protected override void OnMouseDown(MouseButtonEventArgs e) => animateBrush(downColor);
    protected override void OnMouseLeave(MouseEventArgs e) {
        if (IsEnabled) animateBrush(IsTrue ? trueColor : falseColor);
    }

    public bool IsTrue {
        get { return (bool)GetValue(IsTrueProperty); }
        set { SetValue(IsTrueProperty, value); }
    }
    public static readonly DependencyProperty IsTrueProperty =
        DependencyProperty.Register("IsTrue", typeof(bool), typeof(BiState), new PropertyMetadata() {
            PropertyChangedCallback = (s, e) => {
                var o = (BiState)s;
                if ((bool)e.NewValue) {
                    o.icon.Data = o.trueGeo;
                    o.animateBrush(o.trueColor);
                }
                else {
                    o.icon.Data = o.falseGeo;
                    o.animateBrush(o.falseColor);
                }
            }
        });
}
