﻿
class WebWindow : Window
{
    HeaderPanel headerPanel;
    StackPanel buttonsPanel;
    ContentControl pageControl;
    ActionButton add, dropDown, minimize, maxRestore, close;
    Grid container, tabContainer;
    Border backgroundBorder;
    ObservableCollection<Page> pages;
    RequestPage requestPage;
    Page selectedPage;
    WindowMenu menu;

    public WebWindow() {
        Height = 640;
        Width = 800;
        WindowStartupLocation = WindowStartupLocation.CenterScreen;
        WindowStyle = WindowStyle.None;
        AllowsTransparency = true;
        Title = "Browser";

        WindowChrome.SetWindowChrome(this, new WindowChrome() {
            ResizeBorderThickness = new Thickness(5, 0, 5, 5),
            CaptionHeight = 0
        });
        pages = new ObservableCollection<Page>();
        pages.CollectionChanged += onPageAdded;
        menu = new WindowMenu(onLogRequested, pages);
        addButtons();

        headerPanel = new HeaderPanel();
        pageControl = new ContentControl();
        Grid.SetColumn(add, 1);
        Grid.SetColumn(buttonsPanel, 2);
        tabContainer = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(){Width = GridLength.Auto},
                new ColumnDefinition(),
                new ColumnDefinition(){Width = GridLength.Auto}
            },
            Children = { headerPanel, add, buttonsPanel }
        };

        Grid.SetRow(pageControl, 1);
        container = new Grid() {
            RowDefinitions = {
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { tabContainer, pageControl }
        };

        backgroundBorder = new Border() {
            Background = Brushes.LightGray,
            CornerRadius = new CornerRadius(5),
            Child = container
        };
        AddVisualChild(backgroundBorder);


        headerPanel.SetBinding(StackPanel.MaxWidthProperty, new MultiBinding() {
            Converter = new HeaderAreaWidthConverter(),
            Bindings = {
                new Binding(nameof(Grid.ActualWidth)){ Source = container },
                new Binding(nameof(StackPanel.ActualWidth)){ Source = buttonsPanel },
                new Binding(nameof(ActionButton.ActualWidth)){ Source = add }
            }
        });
        backgroundBorder.MouseMove += move;
        
        addTab();     
    }

    void addButtons() {
        add = new ActionButton() {
            ToolTip = "add tab",
            Margin = new Thickness(5, 0, 5, 0),
            Icon = Icons.Add,
            Command = addTab,
            HorizontalAlignment = HorizontalAlignment.Left
        };
        dropDown = new ActionButton() {
            ToolTip = "Menu",
            Icon = Icons.DropDown,
            Command = () => menu.IsOpen = true
        };
        var separator = new Separator() {
            Margin = new Thickness(3,0,3,0),
            Style = new Style(typeof(Separator), (Style)FindResource(ToolBar.SeparatorStyleKey)),
            Background = Brushes.Gray
        };
        close = new ActionButton() {
            ToolTip = "Close",
            Width = 16,
            Margin = new Thickness(0, 0, 3, 0),
            Icon = Icons.CloseCircle,
            Command = Application.Current.Shutdown
        };
        maxRestore = new ActionButton() {
            ToolTip = "Maximize",
            Margin = new Thickness(0, 0, 5, 0),
            Icon = Icons.Maximize,
            Command = resize
        };
        minimize = new ActionButton() {
            ToolTip = "Minimize",
            Margin = new Thickness(0, 0, 5, 0),
            Icon = Icons.Minimize,
            Command = () => WindowState = WindowState.Minimized
        };
        buttonsPanel = new StackPanel() {
            Orientation = Orientation.Horizontal,
            VerticalAlignment = VerticalAlignment.Center,
            Children = { dropDown, separator, minimize, maxRestore, close }
        };

    }
    void addTab() {
        var page = new WebPage();
        pages.Add(page);
    }
    void move(object sender, MouseEventArgs e) {
        if (e.Source != backgroundBorder) return;
        if (e.LeftButton == MouseButtonState.Pressed) DragMove();
    }
    void resize() {
        if (WindowState == WindowState.Maximized) {
            ResizeMode = ResizeMode.CanResizeWithGrip;
            WindowState = WindowState.Normal;
            maxRestore.Icon = Icons.Maximize;
            maxRestore.ToolTip = "Maximize";
        }
        else {
            ResizeMode = ResizeMode.NoResize;
            WindowState = WindowState.Maximized;
            maxRestore.Icon = Icons.Restore;
            maxRestore.ToolTip = "Restore";
        }
    }
    void onPageAdded(object? sender, NotifyCollectionChangedEventArgs e) {
        if (e.Action != NotifyCollectionChangedAction.Add) return;
        var page = (Page)e.NewItems[0];
        page.SelectionChanged += onSelectionChanged;
        page.CloseRequested += onCloseRequested;
        headerPanel.Children.Add(page.Tab);

        if (page.Type == PageType.RequestLog) return; 
        page.Tab.IsSelected = true;
        onSelectionChanged(page);

        if (page.Type != PageType.WebPage) return;
        var p = (WebPage)page;
        p.LogRequested += onLogRequested;
        p.FullScreenRequested += onFullScreenRequested;
        p.NewTabRequested += onNewTabRequested;
    }
    void onNewTabRequested(string url) {
        var page = new WebPage(url);
        pages.Add(page);
    }
    void onFullScreenRequested(bool isFullScreen) {
        if (isFullScreen) {
            tabContainer.Visibility = Visibility.Collapsed;
            ResizeMode = ResizeMode.NoResize;
            WindowState = WindowState.Maximized;
        }
        else {
            tabContainer.Visibility = Visibility.Visible;
            ResizeMode = ResizeMode.CanResizeWithGrip;
            WindowState = WindowState.Normal;
        }
    }
    void onLogRequested() {
        requestPage ??= new RequestPage();
        if (headerPanel.Children.Contains(requestPage.Tab)) return;
        pages.Add(requestPage);
    }
    void onCloseRequested(Page page) {
        page.SelectionChanged -= onSelectionChanged;
        page.CloseRequested -= onCloseRequested;
        int index = headerPanel.Children.IndexOf(page.Tab);
        headerPanel.Children.Remove(page.Tab);
        pages.Remove(page);
        if (page.Type == PageType.WebPage) {
            WebPage p = (WebPage)page;
            p.LogRequested -= onLogRequested;
            p.FullScreenRequested -= onFullScreenRequested;
            p.NewTabRequested -= onNewTabRequested;
        }

        if (pages.Count == 0) Application.Current.Shutdown();
        else {
            if (selectedPage != page) return;
            if (index == 0) onSelectionChanged(pages[0]);
            else onSelectionChanged(pages[index - 1]);
        }
    }
    void onSelectionChanged(Page page) {
        if (selectedPage != null)
            selectedPage.Tab.IsSelected = false;
        selectedPage = page;
        pageControl.Content = page.Content;
    }
    protected override Visual GetVisualChild(int index) => backgroundBorder;
    protected override int VisualChildrenCount => 1;
}