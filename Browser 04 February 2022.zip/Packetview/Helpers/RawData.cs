﻿class RawData
{
    public byte[] Data { get; set; }
    public RawData(byte[] data, int length) {
        Data = new byte[length];
        Array.Copy(data, Data, length);
    }
}

