﻿class Packet
{
    public bool IsReceipt { get; set; }
    public Protocol Type { get; set; }
    public string Time { get; set; }
    public string LocalAddress { get; set; }
    public string RemoteAddress { get; set; }
    public byte[] Data { get; set; }
}
