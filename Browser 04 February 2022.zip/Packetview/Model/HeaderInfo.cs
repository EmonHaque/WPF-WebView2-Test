﻿class HeaderInfo : INotifyPropertyChanged
{
    int receiveCount;
    public int ReceiveCount {
        get { return receiveCount; }
        set { receiveCount = value; onChanged(nameof(ReceiveCount)); }
    }
    int sentCount;
    public int SentCount {
        get { return sentCount; }
        set { sentCount = value; onChanged(nameof(SentCount)); }
    }
    int received;
    public int Received {
        get { return received; }
        set { received = value; onChanged(nameof(Received)); }
    }
    int sent;
    public int Sent {
        get { return sent; }
        set { sent = value; onChanged(nameof(Sent)); }
    }
    string time;
    public string Time {
        get { return time; }
        set { time = value; onChanged(nameof(Time)); }
    }
    public string LocalAddress { get; set; }
    public string RemoteAddress { get; set; }
    public Protocol Type { get; set; }
    public event PropertyChangedEventHandler? PropertyChanged;
    void onChanged(string name) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}

