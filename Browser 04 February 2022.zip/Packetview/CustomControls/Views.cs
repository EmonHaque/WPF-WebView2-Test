﻿class Views : Grid
{
    public CountPage Counter => count;
    CountPage count;
    ConnectionPage connection;
    DoubleAnimation getIn, getOut;
    UIElement currentPage, hiddenPage;
    public Views() {
        Margin = new Thickness(5);
        connection = new ConnectionPage() { Visibility = Visibility.Hidden };
        count = new CountPage(connection);
        Children.Add(connection);
        Children.Add(count);
        initializeAnimations();
        currentPage = count;
        hiddenPage = connection;
        count.SelectionChanged += changeView;
        connection.GoBack += changeView;
        getOut.Completed += reset;
        Unloaded += onUnloaded;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        count.SelectionChanged -= changeView;
        connection.GoBack -= changeView;
        getOut.Completed -= reset;
        Unloaded -= onUnloaded;
    }
    void changeView() {
        if (currentPage is CountPage) {
            getIn.From = ActualWidth;
            getOut.To = -ActualWidth;
        }
        else {
            getIn.From = -ActualWidth;
            getOut.To = ActualWidth;
        }
        currentPage.RenderTransform.BeginAnimation(TranslateTransform.XProperty, getOut);
        hiddenPage.RenderTransform.BeginAnimation(TranslateTransform.XProperty, getIn);
        hiddenPage.Visibility = Visibility.Visible;
    }
    void initializeAnimations() {
        var duration = TimeSpan.FromSeconds(1);
        var ease = new CubicEase() { EasingMode = EasingMode.EaseInOut };
        getIn = new DoubleAnimation() {
            To = 0,
            Duration = duration,
            EasingFunction = ease
        };
        getOut = new DoubleAnimation() {
            Duration = duration,
            EasingFunction = ease
        };       
    }
    void reset(object sender, EventArgs e) {
        currentPage.Visibility = Visibility.Hidden;
        var temp = currentPage;
        currentPage = hiddenPage;
        hiddenPage = temp;
    }
}

