﻿
class PacketWindow : Window
{
    double radius = 5;
    Border windowBorder, titleBar;
    Grid container, titlebarIconGrid/*, contentGrid*/;
    Views views;
    ActionButton close, minimize, maxRestore;

    SocketAsyncEventArgs sniffer;
    byte[] buffer = new byte[65535];
    ConcurrentQueue<RawData> queue;
    
    Thread processor;
    bool isSniffing;   
    IPAddress address;

    public PacketWindow() {
        Height = 640;
        Width = 800;
        WindowStartupLocation = WindowStartupLocation.CenterScreen;
        WindowStyle = WindowStyle.None;
        AllowsTransparency = true;
        Title = "Sniffer";
        WindowChrome.SetWindowChrome(this, new WindowChrome() {
            ResizeBorderThickness = new Thickness(0, 0, 5, 5),
            CaptionHeight = 0
        });
        addTitlebar();
        titleBar = new Border() {
            CornerRadius = new CornerRadius(radius, radius, 0, 0),
            Background = Brushes.Gray,
            Height = 24,
            Child = titlebarIconGrid
        };
        views = new Views();
        Grid.SetRow(views, 1);
        container = new Grid() {
            Background = Brushes.LightGray,
            RowDefinitions = {
                    new RowDefinition() { Height = GridLength.Auto },
                    new RowDefinition()
                },
            Children = { titleBar, views }
        };
        windowBorder = new Border() {
            Background = Brushes.White,
            CornerRadius = new CornerRadius(radius),
            BorderThickness = new Thickness(1),
            BorderBrush = Brushes.LightBlue,
            Child = container
        };
        AddVisualChild(windowBorder);
        titleBar.MouseLeftButtonDown += handleResize;
        titleBar.MouseMove += move;
        queue = new ConcurrentQueue<RawData>();
    }
   
    void move(object sender, MouseEventArgs e) {
        if (e.LeftButton == MouseButtonState.Pressed) DragMove();
    }
    void handleResize(object sender, MouseButtonEventArgs e) {
        if (e.ClickCount == 2) resize();
    }
    void addTitlebar() {
        close = new ActionButton() {
            Width = 16,
            ToolTip = "Close",
            Margin = new Thickness(0, 0, 5, 0),
            Icon = Icons.CloseCircle,
            Command = Application.Current.Shutdown
        };
        maxRestore = new ActionButton() {
            ToolTip = "Maximize",
            Margin = new Thickness(0, 0, 5, 0),
            Icon = Icons.Maximize,
            Command = resize
        };
        minimize = new ActionButton() {
            ToolTip = "Minimize",
            Margin = new Thickness(0, 0, 5, 0),
            Icon = Icons.Minimize,
            Command = () => WindowState = WindowState.Minimized
        };
        var title = new TextBlock() {
            Text = Title,
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(5, 0, 0, 0),
            FontWeight = FontWeights.Bold,
            Foreground = Brushes.DarkSlateGray
        };
        Grid.SetColumn(close, 3);
        Grid.SetColumn(maxRestore, 2);
        Grid.SetColumn(minimize, 1);
        titlebarIconGrid = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
            Children = { title, close, maxRestore, minimize }
        };
    }
    void resize() {
        if (WindowState == WindowState.Maximized) {
            ResizeMode = ResizeMode.CanResizeWithGrip;
            WindowState = WindowState.Normal;
            maxRestore.Icon = Icons.Maximize;
            maxRestore.ToolTip = "Maximize";
        }
        else {
            ResizeMode = ResizeMode.NoResize;
            WindowState = WindowState.Maximized;
            maxRestore.Icon = Icons.Restore;
            maxRestore.ToolTip = "Restore";
        }
    }
    void startSniffing() {
        byte[] byTrue = new byte[4] { 1, 0, 0, 0 };
        byte[] byOut = new byte[4] { 1, 0, 0, 0 };
        address = IPAddress.Parse("127.0.0.1");
        sniffer = new SocketAsyncEventArgs();
        sniffer.AcceptSocket = new Socket(AddressFamily.InterNetwork, SocketType.Raw, ProtocolType.IP);
        sniffer.AcceptSocket.Bind(new IPEndPoint(address, 0));
        sniffer.AcceptSocket.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.HeaderIncluded, true);
        sniffer.AcceptSocket.IOControl(IOControlCode.ReceiveAll, byTrue, byOut);
        sniffer.Completed += onReceive;
        if (!sniffer.AcceptSocket.ReceiveAsync(sniffer))
            onReceive(null, sniffer);
        //sniffer.BeginReceive(buffer, 0, buffer.Length, SocketFlags.None, onReceive, null);
        isSniffing = true;
        processor = new Thread(process);
        processor.Start();
    }
    void onReceive(object? sender, SocketAsyncEventArgs e) {
        try {
            int length = sniffer.AcceptSocket.Receive(buffer);
            var packet = new RawData(buffer, length);
            queue.Enqueue(packet);
            if (!e.AcceptSocket.ReceiveAsync(e))
                onReceive(null, sniffer);
        }
        catch { if (!isSniffing) return; }
    }
    //void onReceive(IAsyncResult ar) {
    //    int length = sniffer.EndReceive(ar);
    //    var packet = new Packet(buffer, length);
    //    queue.Enqueue(packet);
    //    sniffer.BeginReceive(buffer, 0, buffer.Length, SocketFlags.None, onReceive, null);
    //}
    void process() {
        while (isSniffing) {
            // try
            RawData packet;
            var success = queue.TryDequeue(out packet);
            if (!success) {
                Thread.Sleep(500);
                continue;
            }
            var ipHeader = new IPHeader(packet.Data, packet.Data.Length);
            bool isReceipt = true;
            if (ipHeader.SourceAddress.Equals(address)) isReceipt = false;

            switch (ipHeader.ProtocolType) {
                case Protocol.TCP: views.Counter.handleTCP(Protocol.TCP, isReceipt, ipHeader); break;
                case Protocol.UDP: views.Counter.handleUDP(isReceipt, ipHeader); break;
                case Protocol.Unknown: views.Counter.handleUnknown(isReceipt, ipHeader); break;
            }
        }
    }

    protected override void OnActivated(EventArgs e) {
        base.OnActivated(e);
        startSniffing();
    }
    protected override void OnClosing(CancelEventArgs e) {
        titleBar.MouseLeftButtonDown -= handleResize;
        titleBar.MouseMove -= move;
        if(sniffer is not null) {
            sniffer.Completed -= onReceive;
            sniffer.AcceptSocket.Shutdown(SocketShutdown.Both);
            sniffer.AcceptSocket.Close();
        }
        isSniffing = false;
        base.OnClosing(e);
    }
    protected override Visual GetVisualChild(int index) => windowBorder;
    protected override int VisualChildrenCount => 1;
}