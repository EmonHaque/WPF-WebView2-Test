﻿class App : Application
{
    PacketWindow window;
    public App() {
        Current.Resources.Add(SystemParameters.VerticalScrollBarWidthKey, Constants.ScrollbarThickness);
        Current.Resources.Add(SystemParameters.HorizontalScrollBarHeightKey, Constants.ScrollbarThickness);
        Control.StyleProperty.OverrideMetadata(typeof(ScrollBar), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = { new Setter(ScrollBar.TemplateProperty, new VScrollTemplate()) },
                Triggers = {
                        new Trigger() {
                            Property = ScrollBar.OrientationProperty,
                            Value = Orientation.Horizontal,
                            Setters = { new Setter(ScrollBar.TemplateProperty, new HScrollTemplate()) }
                        }
                    }
            }
        });
    }
    [STAThread]
    public static void Main(string[] args) => new App().Run();
    protected override void OnStartup(StartupEventArgs e) {
        if (e.Args.Length == 0) {
            if (!IsRunningAsAdministrator()) {
                var process = new ProcessStartInfo(AppDomain.CurrentDomain.FriendlyName);
                process.UseShellExecute = true;
                process.Verb = "runas";
                Process.Start(process);
                App.Current.Shutdown();
            }
        }

        window = new PacketWindow();
        window.Dispatcher.UnhandledException += unhandledHandler;
        window.Show();
    }

    void unhandledHandler(object sender, DispatcherUnhandledExceptionEventArgs e) {
        InfoDialog.Activate(window, "Exception", e.Exception.Message + "\n" + e.Exception.StackTrace);
        e.Handled = true;
    }

    bool IsRunningAsAdministrator() {
        var identity = WindowsIdentity.GetCurrent();
        var principal = new WindowsPrincipal(identity);
        return principal.IsInRole(WindowsBuiltInRole.Administrator);
    }
}

