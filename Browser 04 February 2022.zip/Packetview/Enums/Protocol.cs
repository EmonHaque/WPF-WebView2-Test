﻿enum Protocol
{
    TCP = 6,
    UDP = 17,
    Unknown = -1
}
