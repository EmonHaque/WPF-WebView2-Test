﻿class HeaderInfoTemplate : Grid
{
    TextBlock localAddress, remoteAddress, received, sent, time, receivedCount, sentCount;
    ColorAnimation anim;
    SolidColorBrush brush;

    public HeaderInfoTemplate() {
        brush = new SolidColorBrush(Colors.Transparent);
        Background = brush;

        localAddress = new TextBlock();
        remoteAddress = new TextBlock();
        received = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        sent = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        time = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        receivedCount = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        sentCount = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };

        Grid.SetColumn(remoteAddress, 1);
        Grid.SetColumn(received, 2);
        Grid.SetColumn(sent, 3);
        Grid.SetColumn(time, 4);
        Grid.SetColumn(receivedCount, 5);
        Grid.SetColumn(sentCount, 6);

        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(90) });
        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(90) });
        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(90) });
        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(60) });
        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(60) });

        Children.Add(localAddress);
        Children.Add(remoteAddress);
        Children.Add(received);
        Children.Add(sent);
        Children.Add(time);
        Children.Add(receivedCount);
        Children.Add(sentCount);

        localAddress.SetBinding(TextBlock.TextProperty, new Binding(nameof(HeaderInfo.LocalAddress)));
        remoteAddress.SetBinding(TextBlock.TextProperty, new Binding(nameof(HeaderInfo.RemoteAddress)));
        received.SetBinding(TextBlock.TextProperty, new Binding(nameof(HeaderInfo.Received)) { StringFormat = Constants.NumericFormat });
        sent.SetBinding(TextBlock.TextProperty, new Binding(nameof(HeaderInfo.Sent)) { StringFormat = Constants.NumericFormat });
        time.SetBinding(TextBlock.TextProperty, new Binding(nameof(HeaderInfo.Time)));
        receivedCount.SetBinding(TextBlock.TextProperty, new Binding(nameof(HeaderInfo.ReceiveCount)) { StringFormat = Constants.NumericFormat });
        sentCount.SetBinding(TextBlock.TextProperty, new Binding(nameof(HeaderInfo.SentCount)) { StringFormat = Constants.NumericFormat });

        anim = new ColorAnimation() {
            Duration = TimeSpan.FromMilliseconds(750),
            From = Colors.CornflowerBlue,
            To = Colors.Transparent
        };
        var count = DependencyPropertyDescriptor.FromProperty(TextBlock.TextProperty, typeof(TextBlock));
        count.AddValueChanged(receivedCount, (s, a) => brush.BeginAnimation(SolidColorBrush.ColorProperty, anim));
        count.AddValueChanged(sentCount, (s, a) => brush.BeginAnimation(SolidColorBrush.ColorProperty, anim));
    }
}

