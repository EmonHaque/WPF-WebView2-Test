﻿class PacketTemplate : Grid
{
    Path icon;
    TextBlock time, length;
    public PacketTemplate() {
        time = new TextBlock();
        length = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        icon = new Path() {
            Margin = new Thickness(0,0,5,0),
            Width = 12,
            Height = 12,
            Stretch = Stretch.Uniform
        };
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition());
        SetColumn(time, 1);
        SetColumn(length, 2);
        Children.Add(icon);
        Children.Add(time);
        Children.Add(length);
        //time.SetBinding(TextBlock.TextProperty, new Binding(nameof(Packet.Time)));
        //length.SetBinding(TextBlock.TextProperty, new Binding("Data.Length") { StringFormat = "N0" });      
    }
    public override void EndInit() {
        base.EndInit();
        var packet = (Packet)DataContext;
        if (packet.IsReceipt) {
            icon.Data = Geometry.Parse(Icons.Download);
            icon.Fill = Brushes.Green;
        }
        else {
            icon.Data = Geometry.Parse(Icons.Upload);
            icon.Fill = Brushes.Coral;
        }
        time.Text = packet.Time;
        length.Text = packet.Data.Length.ToString("N0");
    }

}

