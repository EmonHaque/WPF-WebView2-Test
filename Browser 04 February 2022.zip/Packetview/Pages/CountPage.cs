﻿class CountPage : Grid
{
    ConnectionPage connection;
    long tcpRecvTotal, tcpSentTotal, udpRecvTotal, udpSentTotal, unknownRecvTotal, unknownSentTotal;
    long tcpRecvCountTotal, tcpSentCountTotal, udpRecvCountTotal, udpSentCountTotal, unknownRecvCountTotal, unknownSentCountTotal;
    ListBox tcpBox, udpBox, unknownBox;
    Run tcpRecv, tcpSent, udpRecv, udpSent, unknownRecv, unknownSent;
    Run tcpRecvCount, tcpSentCount, udpRecvCount, udpSentCount, unknownRecvCount, unknownSentCount;
    Run tcpConnections, udpConnections, unknownConnctions;
    Grid tcpGrid, udpGrid, unknownGrid;
    string multicast = "239.255.255.250 : 1900";
    public event Action SelectionChanged;

    public CountPage(ConnectionPage connection) {
        this.connection = connection;
        RowDefinitions.Add(new RowDefinition() { Height = new GridLength(3, GridUnitType.Star) });
        RowDefinitions.Add(new RowDefinition() { Height = new GridLength(3, GridUnitType.Star) });
        RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });
        addBoxes();
        addBlocks();
        tcpBox.MouseDoubleClick += onDoubleClick;
        udpBox.MouseDoubleClick += onDoubleClick;
        unknownBox.MouseDoubleClick += onDoubleClick;
        Unloaded += onUnloaded;
        RenderTransform = new TranslateTransform(0, 0);
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        tcpBox.MouseDoubleClick -= onDoubleClick;
        udpBox.MouseDoubleClick -= onDoubleClick;
        unknownBox.MouseDoubleClick -= onDoubleClick;
        Unloaded -= onUnloaded;
    }
    void onDoubleClick(object sender, MouseButtonEventArgs e) {
        var box = (ListBox)sender;
        if (box.SelectedIndex == -1) return;
        
        SelectionChanged?.Invoke();
        connection.SelectedConnection = (HeaderInfo)box.SelectedItem;
    }
    void addBlocks() {
        tcpRecv = new Run();
        tcpSent = new Run();
        tcpRecvCount = new Run();
        tcpSentCount = new Run();

        udpRecv = new Run();
        udpSent = new Run();
        udpRecvCount = new Run();
        udpSentCount = new Run();

        unknownRecv = new Run();
        unknownSent = new Run();
        unknownRecvCount = new Run();
        unknownSentCount = new Run();

        tcpConnections = new Run();
        udpConnections = new Run();
        unknownConnctions = new Run();

        var tcpRevcBlock = new TextBlock() {
            Inlines = { tcpRecv, new Run(" bytes in "), tcpRecvCount, new Run(" packets") },
            Margin = new Thickness(5, 0, 10, 0)
        };
        var tcpSentBlock = new TextBlock() {
            Inlines = { tcpSent, new Run(" bytes in "), tcpSentCount, new Run(" packets | "), tcpConnections, new Run(" connections") },
            Margin = new Thickness(5, 0, 0, 0)
        };

        var udpRecvBlock = new TextBlock() {
            Inlines = { udpRecv, new Run(" bytes in "), udpRecvCount, new Run(" packets") },
            Margin = new Thickness(5, 0, 10, 0)
        };
        var udpSentBlock = new TextBlock() {
            Inlines = { udpSent, new Run(" bytes in "), udpSentCount, new Run(" packets | "), udpConnections, new Run(" connections") },
            Margin = new Thickness(5, 0, 0, 0)
        };

        var unknownRecvBlock = new TextBlock() {
            Inlines = { unknownRecv, new Run(" bytes in "), unknownRecvCount, new Run(" packets") },
            Margin = new Thickness(5, 0, 10, 0)
        };
        var unknownSentBlock = new TextBlock() {
            Inlines = { unknownSent, new Run(" bytes in "), unknownSentCount, new Run(" packets | "), unknownConnctions, new Run(" connections") },
            Margin = new Thickness(5, 0, 0, 0)
        };
        tcpGrid.Children.Add(new StackPanel() {
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Right,
            Margin = new Thickness(0, 0, 0, 2),
            Children = { Helper.getIcon(Icons.Download), tcpRevcBlock, Helper.getIcon(Icons.Upload), tcpSentBlock }
        });
        udpGrid.Children.Add(new StackPanel() {
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Right,
            Margin = new Thickness(0, 5, 0, 2),
            Children = { Helper.getIcon(Icons.Download), udpRecvBlock, Helper.getIcon(Icons.Upload), udpSentBlock }
        });
        unknownGrid.Children.Add(new StackPanel() {
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Right,
            Margin = new Thickness(0, 5, 0, 2),
            Children = { Helper.getIcon(Icons.Download), unknownRecvBlock, Helper.getIcon(Icons.Upload), unknownSentBlock }
        });
    }
    void addBoxes() {
        var template = Helper.GetDataTemplate(typeof(HeaderInfoTemplate));
        Resources.Add(typeof(ListBox), new Style() {
            Setters = {
                new Setter(ListBox.HorizontalContentAlignmentProperty, HorizontalAlignment.Stretch),
                new Setter(ListBox.BorderThicknessProperty, new Thickness(0,1,0,1)),
                new Setter(ListBox.BorderBrushProperty, Brushes.CornflowerBlue),
                new Setter(ListBox.BackgroundProperty, null)
            }
        });
        Resources.Add("X", new Style() {
            Setters = {
                new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                new Setter(ScrollViewer.TemplateProperty, new ListBoxScrollTemplate())
            }
        });
        tcpBox = new ListBox() {
            ItemTemplate = template,
            Resources = { { typeof(ScrollViewer), (Style)FindResource("X") } }
        };
        Grid.SetRow(tcpBox, 1);
        udpBox = new ListBox() {
            ItemTemplate = template,
            Resources = { { typeof(ScrollViewer), (Style)FindResource("X") } }
        };
        Grid.SetRow(udpBox, 1);
        unknownBox = new ListBox() {
            ItemTemplate = template,
            Resources = { { typeof(ScrollViewer), (Style)FindResource("X") } }
        };
        Grid.SetRow(unknownBox, 1);
        tcpGrid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { new TextBlock() { Text = "TCP", VerticalAlignment = VerticalAlignment.Center, FontWeight = FontWeights.Bold }, tcpBox }
        };
        udpGrid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { new TextBlock() { Text = "UDP", VerticalAlignment = VerticalAlignment.Center, FontWeight = FontWeights.Bold }, udpBox }
        };
        unknownGrid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { new TextBlock() { Text = "Unknown", VerticalAlignment = VerticalAlignment.Center, FontWeight = FontWeights.Bold }, unknownBox }
        };

        Grid.SetRow(udpGrid, 1);
        Grid.SetRow(unknownGrid, 2);
        Children.Add(tcpGrid);
        Children.Add(udpGrid);
        Children.Add(unknownGrid);
    }
    
    public void handleUnknown(bool isReceipt, IPHeader header) {
        ListBox box = unknownBox;
        string localAddress, remoteAddress;
        int length = header.TotalLength;

        if (isReceipt) {
            localAddress = header.DestinationAddress.ToString();
            remoteAddress = header.SourceAddress.ToString();
            unknownRecvTotal += length;
            unknownRecvCountTotal++;
        }
        else {
            remoteAddress = header.DestinationAddress.ToString();
            localAddress = header.SourceAddress.ToString();
            unknownSentTotal += length;
            unknownSentCountTotal++;
        }
        bool isFound = false;
        HeaderInfo found = null;

        App.Current.Dispatcher.Invoke(() => {
            foreach (HeaderInfo item in box.Items) {
                if (item.LocalAddress.Equals(localAddress) && item.RemoteAddress.Equals(remoteAddress)) {
                    found = item;
                    isFound = true;
                    break;
                }
            }
        });

        var time = DateTime.Now.ToString("HH:mm:ss");
        if (isFound) {
            found.Time = time;
            if (isReceipt) {
                found.Received += length;
                found.ReceiveCount++;
                App.Current.Dispatcher.Invoke(() => {
                    unknownRecv.Text = found.Received.ToString("N0");
                    unknownRecvCount.Text = found.ReceiveCount.ToString("N0");
                });
            }
            else {
                found.Sent += length;
                found.SentCount++;
                App.Current.Dispatcher.Invoke(() => {
                    unknownSent.Text = found.Sent.ToString("N0");
                    unknownSentCount.Text = found.SentCount.ToString("N0");
                });
            }
        }
        else {
            var info = new HeaderInfo() {
                Time = time,
                LocalAddress = localAddress,
                RemoteAddress = remoteAddress
            };
            if (isReceipt) {
                info.ReceiveCount = 1;
                info.Received = length;
            }
            else {
                info.SentCount = 1;
                info.Sent = length;
            }
            App.Current.Dispatcher.Invoke(() => {
                info.Type = Protocol.Unknown;
                box.Items.Insert(0, info);
                unknownConnctions.Text = box.Items.Count.ToString("N0");
            });
        }
        var packet = new Packet() {
            IsReceipt = isReceipt,
            Type = Protocol.Unknown,
            Time = time,
            LocalAddress = localAddress,
            RemoteAddress = remoteAddress,
            Data = header.RawData
        };
        App.Current.Dispatcher.Invoke(() => {
            unknownSent.Text = unknownSentTotal.ToString("N0");
            unknownSentCount.Text = unknownSentCountTotal.ToString("N0");
            unknownRecv.Text = unknownRecvTotal.ToString("N0");
            unknownRecvCount.Text = unknownRecvCountTotal.ToString("N0");
            connection.packets.Add(packet);
        });
    }
    public void handleUDP(bool isReceipt, IPHeader header) {
        var udpHeader = new UDPHeader(header.Data, header.MessageLength);
        ListBox box = udpBox;
        string localAddress, remoteAddress;
        int length = header.TotalLength;
        //if (udpHeader.DestinationPort == "53" || udpHeader.SourcePort == "53") DNSHeader
        if (isReceipt) {
            localAddress = header.DestinationAddress.ToString() + " : " + udpHeader.DestinationPort;
            remoteAddress = header.SourceAddress.ToString() + " : " + udpHeader.SourcePort;

            if (localAddress.Equals(multicast) || remoteAddress.Equals(multicast)) return;

            udpRecvTotal += length;
            udpRecvCountTotal++;
        }
        else {
            remoteAddress = header.DestinationAddress.ToString() + " : " + udpHeader.DestinationPort;
            localAddress = header.SourceAddress.ToString() + " : " + udpHeader.SourcePort;

            if (localAddress.Equals(multicast) || remoteAddress.Equals(multicast)) return;
            udpSentTotal += length;
            udpSentCountTotal++;
        }


        bool isFound = false;
        HeaderInfo found = null;

        App.Current.Dispatcher.Invoke(() => {
            foreach (HeaderInfo item in box.Items) {
                if (item.LocalAddress.Equals(localAddress) && item.RemoteAddress.Equals(remoteAddress)) {
                    found = item;
                    isFound = true;
                    break;
                }
            }
        });

        var time = DateTime.Now.ToString("HH:mm:ss");
        if (isFound) {
            found.Time = time;
            if (isReceipt) {
                found.Received += length;
                found.ReceiveCount++;
            }
            else {
                found.Sent += length;
                found.SentCount++;
            }
        }
        else {
            var info = new HeaderInfo() {
                Time = time,
                LocalAddress = localAddress,
                RemoteAddress = remoteAddress
            };
            if (isReceipt) {
                info.ReceiveCount = 1;
                info.Received = length;
            }
            else {
                info.SentCount = 1;
                info.Sent = length;
            }
            App.Current.Dispatcher.Invoke(() => {
                info.Type = Protocol.UDP;
                box.Items.Insert(0, info);
                udpConnections.Text = box.Items.Count.ToString("N0");
            });
        }
        var packet = new Packet() {
            IsReceipt = isReceipt,
            Type = Protocol.UDP,
            Time = time,
            LocalAddress = localAddress,
            RemoteAddress = remoteAddress,
            Data = header.RawData
        };
        App.Current.Dispatcher.Invoke(() => {
            udpSent.Text = udpSentTotal.ToString("N0");
            udpSentCount.Text = udpSentCountTotal.ToString("N0");
            udpRecv.Text = udpRecvTotal.ToString("N0");
            udpRecvCount.Text = udpRecvCountTotal.ToString("N0");
            connection.packets.Add(packet);
        });
    }
    public void handleTCP(Protocol proto, bool isReceipt, IPHeader header) {
        var tcpHeader = new TCPHeader(header.Data, header.MessageLength);
        ListBox box = null;
        string localAddress, remoteAddress;
        int length = header.TotalLength;
        //if (tcpHeader.DestinationPort == "53" || tcpHeader.SourcePort == "53") DNSHeader
        
        if (isReceipt) {
            box = tcpBox;
            localAddress = header.DestinationAddress.ToString() + " : " + tcpHeader.DestinationPort;
            remoteAddress = header.SourceAddress.ToString() + " : " + tcpHeader.SourcePort;
            tcpRecvTotal += length;
            tcpRecvCountTotal++;
        }
        else {
            box = tcpBox;
            remoteAddress = header.DestinationAddress.ToString() + " : " + tcpHeader.DestinationPort;
            localAddress = header.SourceAddress.ToString() + " : " + tcpHeader.SourcePort;
            tcpSentTotal += length;
            tcpSentCountTotal++;
        }
        
        bool isFound = false;
        HeaderInfo found = null;

        App.Current.Dispatcher.Invoke(() => {
            foreach (HeaderInfo item in box.Items) {
                if (item.LocalAddress.Equals(localAddress) && item.RemoteAddress.Equals(remoteAddress)) {
                    found = item;
                    isFound = true;
                    break;
                }
            }
        });

        var time = DateTime.Now.ToString("HH:mm:ss");
        if (isFound) {
            found.Time = time;
            if (isReceipt) {
                found.Received += length;
                found.ReceiveCount++;
            }
            else {
                found.Sent += length;
                found.SentCount++;
            }
        }
        else {
            var info = new HeaderInfo() {
                Time = time,
                LocalAddress = localAddress,
                RemoteAddress = remoteAddress
            };
            if (isReceipt) {
                info.ReceiveCount = 1;
                info.Received = length;
            }
            else {
                info.SentCount = 1;
                info.Sent = length;
            }
            App.Current.Dispatcher.Invoke(() => {
                info.Type = Protocol.TCP;
                box.Items.Insert(0, info);
                tcpConnections.Text = box.Items.Count.ToString("N0");
            });
        }
        var packet = new Packet() {
            IsReceipt = isReceipt,
            Type = Protocol.TCP,
            Time = time,
            LocalAddress = localAddress,
            RemoteAddress = remoteAddress,
            Data = header.RawData
        };
        App.Current.Dispatcher.Invoke(() => {
            tcpSent.Text = tcpSentTotal.ToString("N0");
            tcpSentCount.Text = tcpSentCountTotal.ToString("N0");
            tcpRecv.Text = tcpRecvTotal.ToString("N0");
            tcpRecvCount.Text = tcpRecvCountTotal.ToString("N0");
            connection.packets.Add(packet);
        });
    }   
}

