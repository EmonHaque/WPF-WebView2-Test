﻿class ConnectionPage : Grid
{
    ActionButton back;
    ListBox listBox;
    TextBox textBox;
    TextBlock connectionName;
    Run sentTimes, recvTimes, sentLength, recvLength;
    Grid content;
    HeaderInfo selectedConnection;
    public HeaderInfo SelectedConnection {
        get { return selectedConnection; }
        set { 
            selectedConnection = value;
            connectionName.Text = value.Type + " Local: " + selectedConnection.LocalAddress + " Remote: " + selectedConnection.RemoteAddress;
            bind();
            packetViewSource.View.Refresh();
        }
    }
    public ObservableCollection<Packet> packets;
    CollectionViewSource packetViewSource;
    public event Action GoBack;

    public ConnectionPage() {
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition());
        packets = new ObservableCollection<Packet>();

        back = new ActionButton() {
            Width = 24,
            ToolTip = "back",
            Margin = new Thickness(0, 0, 5, 0),
            Icon = Icons.ScrollLeft,
            Command = raiseGoBack,
            HorizontalAlignment = HorizontalAlignment.Left
        };
        packetViewSource = new CollectionViewSource() {
            Source = packets,
            IsLiveFilteringRequested = true,
            LiveFilteringProperties = { nameof(HeaderInfo.LocalAddress), nameof(HeaderInfo.RemoteAddress) }
        };
        packetViewSource.View.Filter = filterTCPPackets;
        addContent();
        addRuns();
        var block = new TextBlock() {
            HorizontalAlignment = HorizontalAlignment.Right,
            Inlines = {
                new Run("Sent: "),
                sentLength,
                new Run(" bytes in: "),
                sentTimes,
                new Run(" packets | Received: "),
                recvLength,
                new Run(" bytes in: "),
                recvTimes,
                new Run(" packets")
            }
        };
        var infoPanel = new StackPanel() {
            HorizontalAlignment = HorizontalAlignment.Right,
            Children = {connectionName, block }
        };
        
        Grid.SetRow(content, 1);
        Children.Add(back);
        Children.Add(infoPanel);
        Children.Add(content);      
        RenderTransform = new TranslateTransform(0, 0);

        listBox.SelectionChanged += onSelectionChanged;
        Unloaded += onUnloaded;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        listBox.SelectionChanged -= onSelectionChanged;
        Unloaded -= onUnloaded;
    }
    void onSelectionChanged(object sender, SelectionChangedEventArgs e) {
        var tcp = (Packet)listBox.SelectedItem;
        textBox.Text = Encoding.ASCII.GetString(tcp.Data);
    }
    bool filterTCPPackets(object o) {
        if (SelectedConnection is null) return false;
        var packet = (Packet)o;
        return packet.Type == SelectedConnection.Type &&
            packet.LocalAddress.Equals(SelectedConnection.LocalAddress) &&
            packet.RemoteAddress.Equals(SelectedConnection.RemoteAddress);
    }
    void addRuns() {
        connectionName = new TextBlock() { 
            HorizontalAlignment = HorizontalAlignment.Right,
            FontWeight = FontWeights.Bold
        };
        sentTimes = new Run();
        recvTimes = new Run();
        sentLength = new Run();
        recvLength = new Run();
        
    }
    void bind() {
        BindingOperations.ClearBinding(sentTimes, Run.TextProperty);
        BindingOperations.ClearBinding(recvTimes, Run.TextProperty);
        BindingOperations.ClearBinding(sentLength, Run.TextProperty);
        BindingOperations.ClearBinding(recvLength, Run.TextProperty);
        sentTimes.SetBinding(Run.TextProperty, new Binding(nameof(SelectedConnection.SentCount)) { Source = SelectedConnection });
        recvTimes.SetBinding(Run.TextProperty, new Binding(nameof(SelectedConnection.ReceiveCount)) { Source = SelectedConnection });
        sentLength.SetBinding(Run.TextProperty, new Binding(nameof(SelectedConnection.Sent)) { Source = SelectedConnection });
        recvLength.SetBinding(Run.TextProperty, new Binding(nameof(SelectedConnection.Received)) { Source = SelectedConnection });
    }
    void addContent() {
        listBox = new ListBox() { 
            Background = null,
            BorderThickness = new Thickness(0),
            Padding = new Thickness(5, 5, 0, 0),
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            ItemTemplate = Helper.GetDataTemplate(typeof(PacketTemplate)),
            ItemsSource = packetViewSource.View 
        };
        textBox = new TextBox() {
            TextWrapping = TextWrapping.Wrap,
            Margin = new Thickness(5,0,0,0),
            Padding = new Thickness(5,5,0,0),
            BorderThickness = new Thickness(1,0,0,0),
            BorderBrush = Brushes.CornflowerBlue,
            Background = null,
            IsReadOnly = true
        };
        textBox.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        textBox.SetValue(ScrollViewer.VerticalScrollBarVisibilityProperty, ScrollBarVisibility.Auto);
        Grid.SetColumn(textBox, 1);
        var separator = new Separator() { Background = Brushes.CornflowerBlue, VerticalAlignment = VerticalAlignment.Top };
        Grid.SetColumnSpan(separator, 2);
        content = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(){Width = new GridLength(150)},
                new ColumnDefinition()
            },
            Children = { separator, listBox, textBox }
        };
    }
    void raiseGoBack() => GoBack?.Invoke();
}
