﻿using System.Diagnostics;

class App : Application
{
    public App() {
        Current.DispatcherUnhandledException += unhandledHandler;
        Current.Resources.Add(SystemParameters.VerticalScrollBarWidthKey, Constants.ScrollbarThickness);
        Current.Resources.Add(SystemParameters.HorizontalScrollBarHeightKey, Constants.ScrollbarThickness);
        Control.StyleProperty.OverrideMetadata(typeof(ScrollBar), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = { new Setter(ScrollBar.TemplateProperty, new VScrollTemplate()) },
                Triggers = {
                        new Trigger() {
                            Property = ScrollBar.OrientationProperty,
                            Value = Orientation.Horizontal,
                            Setters = { new Setter(ScrollBar.TemplateProperty, new HScrollTemplate()) }
                        }
                    }
            }
        });
    }
    [STAThread]
    public static void Main(string[] args) => new App().Run();
    protected override void OnStartup(StartupEventArgs e) {
        base.OnStartup(e);
        App.Current.MainWindow = new StatWindow();
        App.Current.MainWindow.Show();
    }
    protected override void OnExit(ExitEventArgs e) {
        Debug.WriteLine("Exiting");
        Current.DispatcherUnhandledException -= unhandledHandler;
        base.OnExit(e);
    }
    void unhandledHandler(object sender, DispatcherUnhandledExceptionEventArgs e) {
        InfoDialog.Activate(App.Current.MainWindow, "Exception", e.Exception.Message + "\n" + e.Exception.StackTrace);
        e.Handled = true;
    }
}
