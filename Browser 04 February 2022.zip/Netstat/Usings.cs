﻿global using System;
global using System.Collections.Generic;
global using System.Linq;
global using System.Text;
global using System.Threading.Tasks;
global using System.Windows;
global using System.Windows.Controls;
global using System.Windows.Input;
global using System.Windows.Media;
global using System.Windows.Media.Animation;
global using System.Windows.Shapes;
global using System.Windows.Controls.Primitives;
global using System.Windows.Shell;
global using System.Windows.Data;
global using System.Windows.Threading;

