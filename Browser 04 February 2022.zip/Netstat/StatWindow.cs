﻿
using System.Net.NetworkInformation;
using System.Threading;
using System.Windows.Documents;

class StatWindow : Window
{
    double radius = 5;
    Border windowBorder, titleBar;
    Grid container, titlebarIconGrid, contentGrid;
    ActionButton close, minimize, maxRestore;
    ListBox tcpListenerBox, udpListenerBox, tcpActiveBox;
    Run tcpLisRun, udpLisRun, tcpActRun;
    Timer timer;
    List<string> tcpListenerList, udpListenerList;
    List<Connection> tcpConnectedList;
    public StatWindow() {
        Height = 640;
        Width = 800;
        WindowStartupLocation = WindowStartupLocation.CenterScreen;
        WindowStyle = WindowStyle.None;
        AllowsTransparency = true;
        Title = "NetStat";
        WindowChrome.SetWindowChrome(this, new WindowChrome() {
            ResizeBorderThickness = new Thickness(0, 0, 5, 5),
            CaptionHeight = 0
        });
        addTitlebar();
        titleBar = new Border() {
            CornerRadius = new CornerRadius(radius, radius, 0, 0),
            Background = Brushes.Gray,
            Height = 24,
            Child = titlebarIconGrid
        };
        tcpLisRun = new Run();
        udpLisRun = new Run();
        tcpActRun = new Run();
        var tcpLisBlock = new TextBlock() { Inlines = {new Run("TCP Listeners: ") { FontWeight = FontWeights.Bold}, tcpLisRun}};
        var udpLisBlock = new TextBlock() { Inlines = { new Run("UDP Listeners: ") { FontWeight = FontWeights.Bold }, udpLisRun } };
        var tcpActBlock = new TextBlock() { 
            Inlines = { new Run("TCP Connected: ") { FontWeight = FontWeights.Bold }, tcpActRun }, 
            Margin = new Thickness(3,0,0,0) 
        };
        Grid.SetColumn(tcpLisBlock, 1);
        Grid.SetColumn(udpLisBlock, 2);

        tcpListenerBox = new ListBox();
        udpListenerBox = new ListBox();
        tcpActiveBox = new ListBox() { 
            ItemTemplate = Helper.GetDataTemplate(typeof(TCPActiveTemplate)),
            HorizontalContentAlignment = HorizontalAlignment.Stretch
        };
        Grid.SetColumn(tcpListenerBox, 1);
        Grid.SetColumn(udpListenerBox, 2);
        contentGrid = new Grid() {
            Background = Brushes.LightGray,
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            ColumnDefinitions = {
                new ColumnDefinition(){Width = new GridLength(4, GridUnitType.Star)},
                new ColumnDefinition(){Width = new GridLength(2, GridUnitType.Star)},
                new ColumnDefinition(){Width = new GridLength(2, GridUnitType.Star)}
            },
            Children = {tcpActBlock, tcpLisBlock, udpLisBlock,  tcpListenerBox, udpListenerBox, tcpActiveBox },
            Resources = {
                {
                    typeof(ListBox),
                    new Style(typeof(ListBox)) {
                        Setters = {
                            new Setter(ListBox.BackgroundProperty, null),
                            new Setter(ListBox.BorderThicknessProperty, new Thickness(0,1,0,0)),
                            new Setter(ListBox.BorderBrushProperty, Brushes.CornflowerBlue),
                            new Setter(ListBox.MarginProperty, new Thickness(3)),
                            new Setter(Grid.RowProperty, 1)
                        }
                    }
                }
            }
        };
        Grid.SetRow(contentGrid, 1);
        container = new Grid() {
            RowDefinitions = {
                    new RowDefinition() { Height = GridLength.Auto },
                    new RowDefinition()
                },
            Children = { titleBar, contentGrid }
        };
        windowBorder = new Border() {
            Background = Brushes.White,
            CornerRadius = new CornerRadius(radius),
            BorderThickness = new Thickness(1),
            BorderBrush = Brushes.LightBlue,
            Child = container
        };
        AddVisualChild(windowBorder);
        titleBar.MouseLeftButtonDown += handleResize;
        titleBar.MouseMove += move;
    }

    void move(object sender, MouseEventArgs e) {
        if (e.LeftButton == MouseButtonState.Pressed) DragMove();
    }
    void handleResize(object sender, MouseButtonEventArgs e) {
        if (e.ClickCount == 2) resize();
    }
    void addTitlebar() {
        close = new ActionButton() {
            Width = 16,
            ToolTip = "Close",
            Margin = new Thickness(0, 0, 5, 0),
            Icon = Icons.CloseCircle,
            Command = Application.Current.Shutdown
        };
        maxRestore = new ActionButton() {
            ToolTip = "Maximize",
            Margin = new Thickness(0, 0, 5, 0),
            Icon = Icons.Maximize,
            Command = resize
        };
        minimize = new ActionButton() {
            ToolTip = "Minimize",
            Margin = new Thickness(0, 0, 5, 0),
            Icon = Icons.Minimize,
            Command = () => WindowState = WindowState.Minimized
        };
        var title = new TextBlock() {
            Text = Title,
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(5, 0, 0, 0),
            FontWeight = FontWeights.Bold,
            Foreground = Brushes.DarkSlateGray
        };
        Grid.SetColumn(close, 3);
        Grid.SetColumn(maxRestore, 2);
        Grid.SetColumn(minimize, 1);
        titlebarIconGrid = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
            Children = { title, close, maxRestore, minimize }
        };
    }
    void resize() {
        if (WindowState == WindowState.Maximized) {
            ResizeMode = ResizeMode.CanResizeWithGrip;
            WindowState = WindowState.Normal;
            maxRestore.Icon = Icons.Maximize;
            maxRestore.ToolTip = "Maximize";
        }
        else {
            ResizeMode = ResizeMode.NoResize;
            WindowState = WindowState.Maximized;
            maxRestore.Icon = Icons.Restore;
            maxRestore.ToolTip = "Restore";
        }
    }

    void log(object? state) {
        tcpListenerList.Clear();
        tcpConnectedList.Clear();
        udpListenerList.Clear();
        var ip = IPGlobalProperties.GetIPGlobalProperties();
        foreach (var tcp in ip.GetActiveTcpConnections()) {
            if (tcp.LocalEndPoint.Port > 0 || tcp.RemoteEndPoint.Port > 0) {
                tcpConnectedList.Add(new Connection() {
                    Local = tcp.LocalEndPoint.Address + " : " + tcp.LocalEndPoint.Port,
                    Remote = tcp.RemoteEndPoint.Address + " : " + tcp.RemoteEndPoint.Port,
                    Status = tcp.State.ToString()
                });                
            }
        }
        foreach (var tcp in ip.GetActiveTcpListeners()) {
            if (tcp.Port > 0) {
                var s = string.Format("{0} : {1}", tcp.Address, tcp.Port);
                tcpListenerList.Add(s);
            }
        }
        foreach (var tcp in ip.GetActiveUdpListeners()) {
            if (tcp.Port > 0) {
                var s = string.Format("{0} : {1}", tcp.Address, tcp.Port);
                udpListenerList.Add(s);
            }
        }
        App.Current.Dispatcher.Invoke(() => {
            tcpActiveBox.ItemsSource = null;
            tcpListenerBox.ItemsSource = null;
            udpListenerBox.ItemsSource = null;
            tcpActiveBox.ItemsSource = tcpConnectedList;
            tcpListenerBox.ItemsSource = tcpListenerList;
            udpListenerBox.ItemsSource = udpListenerList;
            tcpActRun.Text = tcpConnectedList.Count.ToString("N0");
            tcpLisRun.Text = tcpListenerList.Count.ToString("N0");
            udpLisRun.Text = udpListenerList.Count.ToString("N0");
        });

    }
    protected override void OnActivated(EventArgs e) {
        base.OnActivated(e);
        timer = new Timer(log, null, 0, 2000);
        tcpConnectedList = new List<Connection>();
        tcpListenerList = new List<string>();
        udpListenerList = new List<string>();
    }
    protected override Visual GetVisualChild(int index) => windowBorder;
    protected override int VisualChildrenCount => 1;
}

