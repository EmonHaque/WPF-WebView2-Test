﻿class Connection
{
    public string Local { get; set; }
    public string Remote { get; set; }
    public string Status { get; set; }
}

