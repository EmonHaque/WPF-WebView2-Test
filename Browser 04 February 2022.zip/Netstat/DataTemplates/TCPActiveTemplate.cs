﻿class TCPActiveTemplate :Grid
{
    TextBlock local, remote, status;
    public TCPActiveTemplate() {
        local = new TextBlock();
        remote = new TextBlock();
        status = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right};
        Grid.SetColumn(remote, 1);
        Grid.SetColumn(status, 2);
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(75)});
        Children.Add(local);
        Children.Add(remote);
        Children.Add(status);
    }
    public override void EndInit() {
        base.EndInit();
        var con = (Connection)DataContext;
        local.Text = con.Local;
        remote.Text = con.Remote;
        status.Text = con.Status;
    }
}

