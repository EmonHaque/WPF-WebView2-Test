﻿public class Helper
{
    public static DataTemplate GetDataTemplate(Type type) {
        return new DataTemplate() {
            VisualTree = new FrameworkElementFactory(type)
        };
    }
    public static ControlTemplate GetControlTemplate(Type target, Type visual) {
        return new ControlTemplate() {
            TargetType = target,
            VisualTree = new FrameworkElementFactory(visual)           
        };
    }
    public static Path getIcon(string data, Brush fill = null) => new Path() {
        Data = Geometry.Parse(data),
        Fill = fill == null ? Brushes.Black : fill,
        Width = 12,
        Height = 12,
        Stretch = Stretch.Uniform
    };
}
