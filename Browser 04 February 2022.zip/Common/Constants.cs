﻿public class Constants
{
    public const double ScrollbarThickness = 12d;
    public const string NumericFormat = "#,##0;(#,##0);-";
}
