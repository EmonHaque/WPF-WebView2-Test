﻿public class InfiniteCircle : Border
{
    Path arc;
    PointAnimationUsingPath pointAnim;
    BooleanAnimationUsingKeyFrames isLargeAnim;
    double radius = 8;
    double margin = 2;
    public InfiniteCircle() {
        Width = Height = radius * 2;
        Margin = new Thickness(margin);
        Visibility = Visibility.Collapsed;

        double x = Width - margin / 2;
        arc = new Path() {
            VerticalAlignment = VerticalAlignment.Center,
            Stroke = Brushes.CornflowerBlue,
            StrokeThickness = 2,
            Data = new PathGeometry() {
                Figures = {
                        new PathFigure() {
                            StartPoint = new Point(x, radius),
                            Segments = {
                                new ArcSegment() {
                                    IsLargeArc = true,
                                    Point = new Point(x, radius - 0.1),
                                    Size = new Size(radius - margin / 2, radius - margin /2),
                                    SweepDirection = SweepDirection.Clockwise
                                }
                            }
                        }
                    }
            }
        };
        Child = arc;
        pointAnim = new PointAnimationUsingPath() {
            PathGeometry = PathGeometry.CreateFromGeometry(arc.Data),
            Duration = TimeSpan.FromSeconds(2),
            AccelerationRatio = 0.5,
            DecelerationRatio = 0.5,
            RepeatBehavior = RepeatBehavior.Forever
        };
        isLargeAnim = new BooleanAnimationUsingKeyFrames() {
            KeyFrames = {
                    new DiscreteBooleanKeyFrame(false, TimeSpan.FromSeconds(0)),
                    new DiscreteBooleanKeyFrame(true, TimeSpan.FromSeconds(1)),
                    new DiscreteBooleanKeyFrame(false, TimeSpan.FromSeconds(2))
                },
            RepeatBehavior = RepeatBehavior.Forever
        };
        
        IsVisibleChanged += onVisibilityChanged;
        Unloaded += onUnloaded;
    }

    void onVisibilityChanged(object sender, DependencyPropertyChangedEventArgs e) {
        if (Visibility != Visibility.Visible) return;
        var segment = (ArcSegment)((PathGeometry)arc.Data).Figures[0].Segments[0];
        segment.BeginAnimation(ArcSegment.PointProperty, pointAnim);
        segment.BeginAnimation(ArcSegment.IsLargeArcProperty, isLargeAnim);
    }

    void onUnloaded(object sender, RoutedEventArgs e) {
        IsVisibleChanged -= onVisibilityChanged;
        Unloaded -= onUnloaded;
    }
}

