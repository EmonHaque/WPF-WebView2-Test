﻿public class ActionButton : Border
{
    string icon;
    public string Icon {
        get { return icon; }
        set {
            icon = value;
            path.Data = Geometry.Parse(value);
            if (double.IsNaN(Width)) Width = Height = path.Width = path.Height = 12;
            else Height = path.Width = path.Height = Width;
        }
    }
    bool space;
    public bool Space {
        get { return space; }
        set {
            space = value;
            if (space) Margin = new Thickness(2.5, 0, 2.5, 0);
        }
    }

    public Action Command { get; set; }
    protected SolidColorBrush brush;
    protected ColorAnimation anim;
    protected Color normalColor, highlightColor, downColor;
    Path path;
    public ActionButton() {
        normalColor = Colors.Black;
        highlightColor = Colors.Coral;
        downColor = Colors.Red;
        brush = new SolidColorBrush(normalColor);
        FocusVisualStyle = null;
        Background = Brushes.Transparent;

        VerticalAlignment = VerticalAlignment.Center;
        path = new Path() {
            Fill = brush,
            Stretch = Stretch.Uniform
        };
        Child = path;
        anim = new ColorAnimation() {
            Duration = TimeSpan.FromSeconds(0.5),
            EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
        };
    }
    protected void animateBrush(Color color) {
        anim.To = color;
        brush.BeginAnimation(SolidColorBrush.ColorProperty, anim);
    }
    protected override void OnMouseEnter(MouseEventArgs e) => animateBrush(highlightColor);
    protected override void OnMouseLeave(MouseEventArgs e) => animateBrush(normalColor);
    protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) {
        if (Command != null)
            Command.Invoke();
    }
    protected override void OnMouseDown(MouseButtonEventArgs e) => animateBrush(downColor);    
    public string IconProperty {
        get { return (string)GetValue(IconPropertyProperty); }
        set { SetValue(IconPropertyProperty, value); }
    }
    public static readonly DependencyProperty IconPropertyProperty =
        DependencyProperty.Register("IconProperty", typeof(string), typeof(ActionButton), new PropertyMetadata(null, onIconChanged));


    public Action ActionProperty {
        get { return (Action)GetValue(ActionPropertyProperty); }
        set { SetValue(ActionPropertyProperty, value); }
    }
    public static readonly DependencyProperty ActionPropertyProperty =
        DependencyProperty.Register("ActionProperty", typeof(Action), typeof(ActionButton), new PropertyMetadata(null, onActionChanged));

    private static void onActionChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
        var o = d as ActionButton;
        o.Command = (Action)e.NewValue;
    }

    private static void onIconChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
        var o = d as ActionButton;
        o.Icon = e.NewValue.ToString();
    }
}
